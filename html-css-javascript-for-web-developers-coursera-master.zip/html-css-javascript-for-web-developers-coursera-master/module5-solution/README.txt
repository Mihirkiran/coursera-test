I was asked by numerous students to split module 4 into two modules.

This is why you are now seeing a 'version2' folder in the Assignments folder.

"version2" is the version 2 of this course, i.e., the one with module 4 split
into 2 modules: Module 4 and Module 5.

There are NO NEW LECTURES OR MATERIAL. I just made a logical split and created 2
modules out of previous 1. I hope that's clear.

The old Module 4 assignment is now the version2 Module 5 Assignment.

If anything is not clear, please feel free to ask your questions in the Coursera
Discussions.
